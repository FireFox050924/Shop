import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ProductService {
    public List<Product> findExpensive(List<Product> products, double minPrice) {
        return products.stream().filter(p -> p.getPrice() >= minPrice).collect(Collectors.toList());
    }

    public List<Product> findCheap(List<Product> products, double maxPrice) {
        return products.stream().filter(p -> p.getPrice() <= maxPrice).collect(Collectors.toList());
    }

    public List<Product> findByCategory(List<Product> products, String category) {
        return products.stream()
                .filter(p -> p.getCategoryName().equalsIgnoreCase(category))
                .collect(Collectors.toList());
    }

    public long countByCategory(List<Product> products, String category) {
        return products.stream()
                .filter(p -> p.getCategoryName().equalsIgnoreCase(category))
                .count();
    }

    public Optional<Product> findMostExpensive(List<Product> products) {
        return products.stream().max((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()));
    }

    public Optional<Product> findCheapest(List<Product> products) {
        return products.stream().min((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()));
    }

    public String  getHistoryReport (Client client) {
        List< PayHist > history =  client.getHistory ();
        if ( history.isEmpty ()) return " История   пуста .";

        String header =  String. format ("%-22s | %10s | %-6s | %s", " Товар ", " Цена ", " Статус ", " Детали ");
        String line = "-".repeat(65);


        StringBuilder body = new StringBuilder();
        for (PayHist ph : history) {
            body.append(ph.getReceipt());
        }
        return header + "\n" + line + "\n" + body.toString();
    }
}
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ProductService {

    //товары дороже определенной цены
    public List<Product> findExpensive(List<Product> products, double minPrice) {
        return products.stream()
                .filter(p -> p.getPrice() >= minPrice)
                .collect(Collectors.toList());
    }

    //товары дешевле определенной цены
    public List<Product> findCheap(List<Product> products, double maxPrice) {
        return products.stream()
                .filter(p -> p.getPrice() <= maxPrice)
                .collect(Collectors.toList());
    }

    //товар по категории
    public List<Product> findByCategory(List<Product> products, String category) {
        return products.stream()
                .filter(p -> p.getCategoryName().equalsIgnoreCase(category))
                .collect(Collectors.toList());
    }

    //количество товаров по категории
    public long countByCategory(List<Product> products, String category) {
        return products.stream()
                .filter(p -> p.getCategoryName().equalsIgnoreCase(category))
                .count();
    }

    //самый дорогой товар
    public Optional<Product> findMostExpensive(List<Product> products) {
        return products.stream()
                .max((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()));
    }

    //самый дешевый товар
    public Optional<Product> findCheapest(List<Product> products) {
        return products.stream()
                .min((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()));
    }
}
import java.util.ArrayList;

public class Catalog {
    private ArrayList<Category> list;

    public Catalog() {
        this.list = new ArrayList<>();
    }

    public void addCategory(Category cat) {
        list.add(cat);
    }

    public void showAllInfo() {
        for (Category c : list) {
            c.showCategoryInfo();
        }
    }
}
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Catalog implements ProductRepository {
    private static Catalog instance; //один экземпляр
    private final List<Category> categories = new ArrayList<>();

    private Catalog() {} // зааприщает добавление

    public static Catalog getInstance() { //сингл тон инициализация
        if (instance == null) {
            instance = new Catalog();
        }
        return instance;
    }

    public void addCategory(Category cat) {
        categories.add(cat);
    }

    @Override
    public List<Product> getAllProducts() {
        return categories.stream()
                .flatMap(c -> c.getAllProducts().stream())
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Product> findById(int id) {
        return getAllProducts().stream().filter(p -> p.getId() == id).findFirst();
    }
}
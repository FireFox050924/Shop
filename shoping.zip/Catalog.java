import java.util.ArrayList;
import java.util.List;

public class Catalog {
    private ArrayList<Category> list;

    public Catalog() {
        this.list = new ArrayList<>();
    }

    public void addCategory(Category cat) {
        list.add(cat);
    }

    // Метод для получения ВСЕХ товаров списком
    public List<Product> getAllProductsFromCatalog() {
        List<Product> all = new ArrayList<>();
        for (Category c : list) {
            all.addAll(c.getAllProducts());
        }
        return all;
    }

    public void showAllInfo() {
        for (Category c : list) {
            c.showCategoryInfo();
        }
    }
}
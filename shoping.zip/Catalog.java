import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Catalog implements ProductRepository {
    private static Catalog instance;
    private final List<Category> categories = new ArrayList<>();

    private Catalog() {}

    public static Catalog getInstance() {
        if (instance == null) {
            instance = new Catalog();
        }
        return instance;
    }

    public void addCategory(Category cat) {
        categories.add(cat);
    }

    //выброс исключения
    public Category findCategoryByName(String name) {
        return categories.stream()
                .filter(c -> c.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElseThrow(() -> new CategoryNotFoundException("Категория '" + name + "' не найдена"));
    }

    @Override
    public List<Product> getAllProducts() {
        return categories.stream()
                .flatMap(c -> c.getAllProducts().stream())
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Product> findById(int id) {
        return getAllProducts().stream().filter(p -> p.getId() == id).findFirst();
    }
}
class CategoryNotFoundException extends RuntimeException {
    public CategoryNotFoundException(String message) {
        super(message);
    }
}

class ProductNotFoundException extends RuntimeException {
    public ProductNotFoundException(String message) {
        super(message);
    }
}

class InvalidMenuChoiceException extends RuntimeException {
    public InvalidMenuChoiceException(String message) {
        super(message);
    }
}

class InvalidCreditUseException extends RuntimeException {
    public InvalidCreditUseException(String message) {
        super(message);
    }
}

class InvalidDataException extends RuntimeException {
    public InvalidDataException(String message) {
        super(message);
    }
}
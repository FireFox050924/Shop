public class PayHist { //после создания нельзя изменить
    private final String prodName;
    private final double price;
    private final boolean success;
    private final String statusMsg;

    public PayHist(String prodName, double price, boolean success, String statusMsg) {
        this.prodName = prodName;
        this.price = price;
        this.success = success;
        this.statusMsg = statusMsg;
    }

    public boolean isSuccess() {
        return success;
    }
    public String getStatusMsg() {
        return statusMsg;
    }

    public String getReceipt() {
        return String.format("| %-20s | %8.2f rub | %-4s | %s%n",
                prodName, price, (success ? "OK" : "ERR"), statusMsg);
    }
}
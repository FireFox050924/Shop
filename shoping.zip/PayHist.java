import java.util.Objects;

public class PayHist {
    private final String prodName;
    private final double price;
    private final PaymentStatus status;
    private final String statusMsg;

    public PayHist(String prodName, double price, PaymentStatus status, String statusMsg) {
        this.prodName = prodName;
        this.price = price;
        this.status = status;
        this.statusMsg = statusMsg;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public boolean isSuccess() {
        return status == PaymentStatus.SUCCESS;
    }

    public String getStatusMsg() {
        return statusMsg;
    }

    public String getReceipt() {
        return String.format("| %-20s | %8.2f rub | %-4s | %s%n",
                prodName, price, status.getLabel(), statusMsg);
    }

    @Override
    public String toString() {
        return "PayHist{" +
                "prodName='" + prodName + '\'' +
                ", price=" + price +
                ", status=" + status +
                ", msg='" + statusMsg + '\'' +
                '}';
    }
}
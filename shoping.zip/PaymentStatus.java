public enum PaymentStatus {
    SUCCESS("Оплачено"),
    FAIL("Не оплачено");

    private final String label;

    PaymentStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
import java.util.ArrayList;
import java.util.List;

public class Category {
    private static int nId = 1;
    private final int id;
    private final String name;
    private final List<Product> prods;

    public Category(String name) {
        this.id = nId++;
        this.name = name;
        this.prods = new ArrayList<>();
    }

    public String getName() {
        return name;
    }
    public void addProduct(Product prod) {
        prods.add(prod);
    }

    public List<Product> getAllProducts() {
        return new ArrayList<>(prods);
    }

    public void showCategoryInfo() {
        System.out.println("Категория: " + name);
        prods.forEach(Product::showInfo);
    }
}
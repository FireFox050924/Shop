import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Objects;

public class Category {
    private static int nId = 1;
    private int id;
    private String name;
    private ArrayList<Category> subs;
    private ArrayList<Product> prods;

    public Category(String name) {
        this.id = nId++;
        this.name = name;
        this.subs = new ArrayList<>();
        this.prods = new ArrayList<>();
    }

    public int getId() { return id; }
    public String getName() { return name; }

    public void addSubCategory(Category cat) { subs.add(cat); }
    public void addProduct(Product prod) { prods.add(prod); }

    public ArrayList<Product> getAllProducts() {
        ArrayList<Product> all = new ArrayList<>();
        all.addAll(prods);
        for (Category c : subs) {
            all.addAll(c.getAllProducts());
        }
        return all;
    }
    public void sortByPriceDesc() {
        Collections.sort(prods);
    }

    public void sortByName() {
        Collections.sort(prods, new ProductNameComparator());
    }

    public void showCategoryInfo() {
        System.out.println("Категория: " + name);
        for (Product p : prods) {
            p.showInfo();
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Category)) return false;
        return id == ((Category) obj).id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
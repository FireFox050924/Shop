import java.util.ArrayList;
import java.util.Objects;

public class Category {
    private static int nId = 1;
    private int id;
    private String name;
    private ArrayList<Category> subs;
    private ArrayList<Product> prods;

    public Category(String name) {
        this.id = nId++;
        this.name = name;
        this.subs = new ArrayList<>();
        this.prods = new ArrayList<>();
    }

    public int getId() { return id; }
    public String getName() { return name; }

    public void addSubCategory(Category cat) { subs.add(cat); }
    public void addProduct(Product prod) { prods.add(prod); }

    public ArrayList<Product> getAllProducts() {
        ArrayList<Product> all = new ArrayList<>();
        all.addAll(prods);
        for (Category c : subs) {
            all.addAll(c.getAllProducts());
        }
        return all;
    }

    public void showCategoryInfo() {
        System.out.println(name);
        for (Product p : getAllProducts()) {
            p.showInfo();
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Category)) return false;
        return id == ((Category) obj).id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
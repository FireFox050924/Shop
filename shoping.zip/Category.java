import java.util.ArrayList;
import java.util.Objects;

public class Category {
    private static int nId = 1;
    private int id;
    private String name;
    private ArrayList<Product> prods;

    public Category(String name) {
        this.id = nId++;
        this.name = name;
        this.prods = new ArrayList<>();
    }

    public String getName() { return name; }

    public void addProduct(Product prod) {
        prods.add(prod);
    }

    public ArrayList<Product> getAllProducts() {
        return new ArrayList<>(prods);
    }

    public void showCategoryInfo() {
        System.out.println("Категория: " + name);
        for (Product p : prods) {
            p.showInfo();
        }
    }
}
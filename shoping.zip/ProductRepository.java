import java.util.List;
import java.util.Optional;

//сервисы зависят от интерфейса а не от Catalog
//теперь от этого зависит а не от категории
public interface ProductRepository {
    List<Product> getAllProducts();
    Optional<Product> findById(int id);
}
public interface Financeable {
    double getDebitBalance();      //дебит
    double getCreditAvailable();   //кредит
    boolean hasEnoughMoney(double amount); //общий и то и то
    String getFinancialStatus();   //сатутс
}
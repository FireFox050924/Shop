public class CreditPaymentStrategy implements PaymentStrategy {
    @Override
    public PayHist pay(Client client, Product product) {
        double available = client.getCreditAvailable();
        if (available >= product.getPrice()) {
            client.setCreditDebt(client.getCreditDebt() + product.getPrice());
            return OrderFactory.create(product.getName(), product.getPrice(), true, "Оплачено в кредит");
        }
        return OrderFactory.create(product.getName(), product.getPrice(), false, "Превышен кредитный лимит");
    }
}
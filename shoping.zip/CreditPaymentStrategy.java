public class CreditPaymentStrategy implements PaymentStrategy {
    @Override
    public PayHist pay(Client client, Product product) {
        double available = client.getCreditAvailable();
        PayHist receipt;

        if (available >= product.getPrice()) {
            client.setCreditDebt(client.getCreditDebt() + product.getPrice());
            receipt = OrderFactory.create(product.getName(), product.getPrice(), PaymentStatus.SUCCESS, "Оплачено в кредит");
        } else {
            //искл
            throw new InvalidCreditUseException("Превышен кредитный лимит. Доступно: " + available + ", Цена: " + product.getPrice());
        }

        client.addHistory(receipt);
        return receipt;
    }
}
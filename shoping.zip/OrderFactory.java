//выноска PayHist в одно место (теперь ээто центр для созданых объектов )
public class OrderFactory {
    public static PayHist create(String prodName, double price, boolean success, String message) {
        return new PayHist(prodName, price, success, message);
    }
}
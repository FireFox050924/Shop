public class OrderFactory { //выноска и сборка истории
    public static PayHist create(String prodName, double price, PaymentStatus status, String message) {
        return new PayHist(prodName, price, status, message);
    }
}
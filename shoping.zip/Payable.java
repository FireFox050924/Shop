public interface Payable {
    double getFinalPrice(double basePrice);
    void pay(double amount, boolean useCredit); //оплатить, если кредит то из кредита оплатить
    boolean isPaid();  //флаг оплаты
}
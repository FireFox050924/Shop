public interface Payable {
    double getFinalPrice(double basePrice);
    void pay(double amount, boolean useCredit); //с использыванием кредита или нет
    boolean isPaid();
}
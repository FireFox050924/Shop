public interface Payable {
    double getFinalPrice(double basePrice);
    void pay(double amount);
    boolean isPaid();
}
public class Client extends Person implements Payable, Financeable {
    public int id;

    private double debitAccount;   //дебит
    private double creditLimit;    //лимит кредита
    private double creditDebt;     //текущий кредит

    public boolean paid = false;

    public Client(int id, String name, double initialDebit, double creditLimit) {
        super(name);
        this.id = id;
        this.debitAccount = initialDebit;
        this.creditLimit = creditLimit;
        this.creditDebt = 0.0;
    }

    @Override
    public double getDebitBalance() {
        return debitAccount;
    }

    @Override
    public double getCreditAvailable() {
        return creditLimit - creditDebt;
    }

    @Override
    public boolean hasEnoughMoney(double amount) {
        return (debitAccount + getCreditAvailable()) >= amount;
    }

    @Override
    public String getFinancialStatus() {
        if (creditDebt > 0) return "Есть долг по кредиту";
        if (debitAccount > 1000) return "Богатый";
        if (debitAccount > 0) return "Норм";
        return "Пусто";
    }

    @Override
    public double getFinalPrice(double basePrice) {
        return basePrice;
    }

    @Override
    public void pay(double amount, boolean useCredit) {
        paid = false; //зачистка

        //хватает ли денег
        if (!hasEnoughMoney(amount)) {
            System.out.println("Недостаточно средств даже с кредитом.");
            return;
        }

        // списание
        if (debitAccount >= amount) {
            debitAccount -= amount; //хватат
            paid = true;
        }
        else if (useCredit) {
            double remainingNeeded = amount - debitAccount;// не хватат на дебит
            debitAccount = 0;

            creditDebt += remainingNeeded; // остаток из кредита
            paid = true;
        }
        else {
            System.out.println("На дебете недостаточно средств, а кредит откланён.");
        }
    }

    @Override
    public boolean isPaid() {
        return paid;
    }

    @Override
    public String toString() {
        return String.format("Клиент: %s | Дебет: %.2f | Кред. Долг: %.2f / %.2f",
                name,
                debitAccount,
                creditDebt,
                creditLimit);
    }
}
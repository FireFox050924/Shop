import java.util.ArrayList;
import java.util.List;

public class Client implements Financeable, Payable {
    public final int id;
    private final String name;
    private double debit;
    private final double creditLimit;
    private double creditDebt;
    private final List<PayHist> history; //без последующего изменения

    public Client(int id, String name, double initDebit, double credLimit) {
        this.id = id;
        this.name = name;
        this.debit = initDebit;
        this.creditLimit = credLimit;
        this.creditDebt = 0.0;
        this.history = new ArrayList<>();
    }

    public String getName() {
        return name;
    }
    public double getDebit() {
        return debit;
    }
    public void setDebit(double d) {
        this.debit = d;
    }
    public double getCreditLimit() {
        return creditLimit;
    }
    public double getCreditDebt() {
        return creditDebt;
    }
    public void setCreditDebt(double cd) {
        this.creditDebt = cd;
    }
    public void addHistory(PayHist ph) {
        history.add(ph);
    }
    public List<PayHist> getHistory() {
        return history;
    }

    //финансибл
    @Override public double getDebitBalance() {
        return debit;
    }
    @Override public double getCreditAvailable() {
        return creditLimit - creditDebt;
    }
    @Override public boolean hasEnoughMoney(double amount) {
        return (debit + getCreditAvailable()) >= amount;
    }
    @Override public String getFinancialStatus() {
        if (creditDebt > 0) return "Есть долг";
        if (debit > 1000) return "Богатый";
        if (debit > 0) return "Норм";
        return "Пусто";
    }
    @Override public double getFinalPrice(double basePrice) {
        return basePrice;
    }
    @Override public void pay(double amount, boolean useCredit) {
        System.out.println("Ошибка: Используйте CheckoutService для оплаты.");
    }
    @Override public boolean isPaid() {
        if (history.isEmpty()) return false;
        return history.get(history.size() - 1).isSuccess();
    }

    @Override
    public String toString() {
        return String.format("Клиент: %s | Дебет: %.2f | Долг: %.2f / %.2f",
                name, debit, creditDebt, creditLimit);
    }
}
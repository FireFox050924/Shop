public class Client extends Person implements Payable, Financeable {
    public int id;
    public double wallet;
    public boolean paid = false;

    public Client(int id, String name, double wallet) {
        super(name);
        this.id = id;
        this.wallet = wallet;
    }

    @Override
    public double getFinalPrice(double basePrice) {
        return basePrice;
    }

    @Override
    public void pay(double amount) {
        if (wallet >= amount) {
            wallet -= amount;
            paid = true;
        } else {
            paid = false;
        }
    }

    @Override
    public boolean isPaid() {
        return paid;
    }

    @Override
    public double checkBalance() {
        return wallet;
    }

    @Override
    public boolean hasEnoughMoney(double amount) {
        return wallet >= amount;
    }

    @Override
    public String getFinancialStatus() {
        if (wallet > 1000) return "богатый";
        else if (wallet > 0) return "норм";
        else return "плохо";
    }

    @Override
    public String toString() {
        return "Клиент: " + name + ", Баланс: " + wallet;
    }
}
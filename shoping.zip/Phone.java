public class Phone extends Product {
    public Phone(String name, double price) {
        super(name, price);
    }

    @Override
    public void showInfo() {
        System.out.println(getName() + " " + getPrice());
    }
}
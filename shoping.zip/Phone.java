public class Phone extends Product {
    public Phone(String name, double price) {
        super(name, price);
    }

    @Override
    public void showInfo() {
        System.out.println("Телефон: " + getName() + " " + getPrice());
    }

    @Override
    public String getCategoryName() {
        return "Телефоны";
    }
}
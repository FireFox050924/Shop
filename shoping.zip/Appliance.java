public class Appliance extends Product {
    public Appliance(String name, double price) {
        super(name, price);
    }

    @Override
    public void showInfo() {
        System.out.println("Техника: " + getName() + " " + getPrice());
    }

    @Override
    public String getCategoryName() {
        return "Бытовая техника";
    }
}
public class Appliance extends Product {
    public Appliance(String name, double price) {
        super(name, price);
    }

    @Override
    public void showInfo() {
        System.out.println(getName() + " " + getPrice());
    }
}
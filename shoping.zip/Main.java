/*
есть новый класс продукт и в этот продукт добовляем новый абстрактный метод showInfo
потом в унаследованном классе переопределить метод
создать несколько объектов разных типов (для дополнения списка), создать метод чтобы всё оборачивать список
добовление
с помощью метода showInfo зациклить и показать список из всего списка

#сделать так чтобы были подгруппы (дочерние классы от Product) которые будут вмещать продукты
*/
/*
1)добавляем расширение класса equals toString instanceof hashcod  #не сделано
2)дальше создаём два интерфейса Finansebl Payable
    1.отвечает за покупку (первый метод возращает double gt finl pris(,tp gfhfvtnhf) void второй метод ничего не возращает третий метод возращает bool (isPaid) параметр не принимает)
    2.метод возращает doubl chekbalans (уточнение текущего баланса) второй метод возрощает bool hasenoughmouny денег хватает или нет  третий метод string(а можно и через чтото другое к примеру можно и int) гет финансл статус
3) создаём клас пёрсанал от него наследуется новый клас клиент(id name wallet и расшерение классов (абстракция))
4) надо както интерфейсы связать с программой

*/

/*


*/

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Product p1 = new Computers("ПК Игровой", 111.11);
        Product p2 = new Computers("Монитор", 222.22);
        Product p3 = new Computers("Ноутбук", 333.33);
        Product p4 = new Phone("iPhone", 444.44);
        Product p5 = new Phone("Samsung", 555.55);
        Product p6 = new Phone("Honor", 666.66);
        Product p7 = new Appliance("Тостер", 777.77);
        Product p8 = new Appliance("Холодильник", 888.88);
        Product p9 = new Appliance("Микроволновка", 999.99);

        Category cComputers = new Category("Компьютеры");
        Category cPhones = new Category("Телефоны");
        Category cHome = new Category("Бытовая техника");

        cComputers.addProduct(p1);
        cComputers.addProduct(p2);
        cComputers.addProduct(p3);

        cPhones.addProduct(p4);
        cPhones.addProduct(p5);
        cPhones.addProduct(p6);

        cHome.addProduct(p7);
        cHome.addProduct(p8);
        cHome.addProduct(p9);

        Catalog cat = new Catalog();
        cat.addCategory(cComputers);
        cat.addCategory(cPhones);
        cat.addCategory(cHome);

        cat.showAllInfo();


        Client client = new Client(1, "Алексей", 500.0);
        System.out.println(client);

        Payable pay = client;
        Financeable fin = client;

        double price = p4.getPrice();
        double finalPrice = pay.getFinalPrice(price);
        System.out.println("Итоговая цена: " + finalPrice);

        if (fin.hasEnoughMoney(finalPrice)) {
            pay.pay(finalPrice);
            System.out.println("Оплата прошла успешно");
        } else {
            System.out.println("Не хватило денег. Статус: " + fin.getFinancialStatus());
        }

        System.out.println("Оплачено? " + pay.isPaid());
        System.out.println("Остаток на счёте: " + fin.checkBalance());
        System.out.println("Статус клиента " + fin.getFinancialStatus());
    }
}
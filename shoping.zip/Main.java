import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Product p1 = new Computers("ПК Игровой", 111.11);
        Product p2 = new Computers("Монитор", 222.22);
        Product p3 = new Computers("Ноутбук", 333.33);
        Product p4 = new Phone("iPhone", 444.44);
        Product p5 = new Phone("Samsung", 555.55);
        Product p6 = new Phone("Honor", 666.66);
        Product p7 = new Appliance("Тостер", 777.77);
        Product p8 = new Appliance("Холодильник", 888.88);
        Product p9 = new Appliance("Микроволновка", 999.99);

        Category cComputers = new Category("Компьютеры");
        cComputers.addProduct(p1); cComputers.addProduct(p2); cComputers.addProduct(p3);

        Category cPhones = new Category("Телефоны");
        cPhones.addProduct(p4); cPhones.addProduct(p5); cPhones.addProduct(p6);

        Category cHome = new Category("Бытовая техника");
        cHome.addProduct(p7); cHome.addProduct(p8); cHome.addProduct(p9);

        Catalog catalog = new Catalog();
        catalog.addCategory(cComputers);
        catalog.addCategory(cPhones);
        catalog.addCategory(cHome);

        Client client = new Client(1, "Алексей", 500.0, 5000.0);

        ProductService service = new ProductService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Показать все товары");
            System.out.println("2. Товары дороже X руб.");
            System.out.println("3. Товары дешевле X руб.");
            System.out.println("4. Товары по категории");
            System.out.println("5. Кол-во товаров в категории");
            System.out.println("6. Самый дорогой товар");
            System.out.println("7. Самый дешевый товар");
            System.out.println("8. Информация о клиенте");
            System.out.println("9. Купить товар (по ID)");
            System.out.println("10. Баланс и статус клиента");
            System.out.print("Выбор: ");

            int choice = sc.nextInt();
            List<Product> allProducts = catalog.getAllProductsFromCatalog();

            switch (choice) {
                case 1:
                    System.out.println("Все товары:");
                    allProducts.forEach(System.out::println);
                    break;
                case 2:
                    System.out.print("Введите мин. цену: ");
                    double minP = sc.nextDouble();
                    service.findExpensive(allProducts, minP).forEach(System.out::println);
                    break;
                case 3:
                    System.out.print("Введите макс. цену: ");
                    double maxP = sc.nextDouble();
                    service.findCheap(allProducts, maxP).forEach(System.out::println);
                    break;
                case 4:
                    System.out.print("Введите категорию: ");
                    sc.nextLine();
                    String cat = sc.nextLine();
                    service.findByCategory(allProducts, cat).forEach(System.out::println);
                    break;
                case 5:
                    System.out.print("Введите категорию для подсчета: ");
                    sc.nextLine();
                    String catCount = sc.nextLine();
                    System.out.println("Количество: " + service.countByCategory(allProducts, catCount));
                    break;
                case 6:
                    service.findMostExpensive(allProducts).ifPresentOrElse(
                            p -> System.out.println("Самый дорогой: " + p),
                            () -> System.out.println("Список пуст")
                    );
                    break;
                case 7:
                    service.findCheapest(allProducts).ifPresentOrElse(
                            p -> System.out.println("Самый дешевый: " + p),
                            () -> System.out.println("Список пуст")
                    );
                    break;
                case 8:
                    System.out.println(client);
                    break;

                case 9:
                    System.out.print("Введите ID товара для покупки: ");
                    int buyId = sc.nextInt();

                    Product target = allProducts.stream()
                            .filter(p -> p.getId() == buyId)
                            .findFirst()
                            .orElse(null);

                    if (target != null) {
                        Payable pay = client;
                        Financeable fin = client;

                        double finalPrice = pay.getFinalPrice(target.getPrice());
                        System.out.println("Цена к оплате: " + finalPrice);
                        System.out.println("У вас на дебете: " + fin.getDebitBalance());
                        System.out.println("Доступно в кредит: " + fin.getCreditAvailable());

                        System.out.print("Использовать кредит, если не хватит своих? (да/нет): ");
                        sc.nextLine();
                        String answer = sc.nextLine().toLowerCase();
                        boolean useCredit = answer.equals("да");

                        pay.pay(finalPrice, useCredit);

                        if (client.isPaid()) {
                            System.out.println("Оплата прошла успешно!");
                            System.out.println("Новое состояние: " + client);
                        } else {
                            System.out.println("Оплата не прошла.");
                        }
                    } else {
                        System.out.println("Товар с таким ID не найден.");
                    }
                    break;

                case 10:
                    Financeable finInfo = client;
                    System.out.println("Дебетовый счет: " + finInfo.getDebitBalance());
                    System.out.println("Кредитный долг: " + (finInfo.getCreditAvailable() < 5000 ? (5000 - finInfo.getCreditAvailable()) : 0) + " / Лимит: 5000");
                    System.out.println("Статус: " + finInfo.getFinancialStatus());
                    break;
                default:
                    System.out.println("Неверный ввод");
            }
        }
    }
}
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Catalog catalog = Catalog.getInstance();

        Product p1 = new Computers("ПК Игровой", 111.11);
        Product p2 = new Computers("Монитор", 222.22);
        Product p3 = new Computers("Ноутбук", 333.33);
        Product p4 = new Phone("iPhone", 444.44);
        Product p5 = new Phone("Samsung", 555.55);
        Product p6 = new Phone("Honor", 666.66);
        Product p7 = new Appliance("Тостер", 777.77);
        Product p8 = new Appliance("Холодильник", 888.88);
        Product p9 = new Appliance("Микроволновка", 999.99);

        Category cComputers = new Category("Компьютеры");
        cComputers.addProduct(p1); cComputers.addProduct(p2); cComputers.addProduct(p3);
        catalog.addCategory(cComputers);

        Category cPhones = new Category("Телефоны");
        cPhones.addProduct(p4); cPhones.addProduct(p5); cPhones.addProduct(p6);
        catalog.addCategory(cPhones);

        Category cHome = new Category("Бытовая техника");
        cHome.addProduct(p7); cHome.addProduct(p8); cHome.addProduct(p9);
        catalog.addCategory(cHome);

        Client client = new Client(1, "Алексей", 500.0, 5000.0);
        ProductService productService = new ProductService();
        Scanner sc = new Scanner(System.in);

        PaymentStrategy strategy = new DebitPaymentStrategy();
        //внидрение зависимостей
        CheckoutService checkoutService = new CheckoutService(catalog, strategy);

        while (true) {
            System.out.println("\n1. Показать все товары");
            System.out.println("2. Товары дороже X руб.");
            System.out.println("3. Товары дешевле X руб.");
            System.out.println("4. Товары по категории");
            System.out.println("5. Кол-во товаров в категории");
            System.out.println("6. Самый дорогой товар");
            System.out.println("7. Самый дешевый товар");
            System.out.println("8. Информация о клиенте");
            System.out.println("9. Купить товар (по ID)");
            System.out.println("10. Баланс и статус клиента");
            System.out.println("11. История покупок");
            System.out.println("12. Пополнить счет");
            System.out.println("13. Сменить способ оплаты (Дебет/Кредит)");
            System.out.print("Выбор: ");

            int choice = sc.nextInt();
            var allProducts = catalog.getAllProducts();

            switch (choice) {
                case 1 -> allProducts.forEach(System.out::println);
                case 2 -> {
                    System.out.print("Мин. цена: ");
                    double min = sc.nextDouble();
                    productService.findExpensive(allProducts, min).forEach(System.out::println);
                }
                case 3 -> {
                    System.out.print("Макс. цена: ");
                    double max = sc.nextDouble();
                    productService.findCheap(allProducts, max).forEach(System.out::println);
                }
                case 4 -> {
                    sc.nextLine();
                    System.out.print("Категория: ");
                    String cat = sc.nextLine();
                    productService.findByCategory(allProducts, cat).forEach(System.out::println);
                }
                case 5 -> {
                    sc.nextLine();
                    System.out.print("Категория: ");
                    String cat = sc.nextLine();
                    System.out.println("Количество: " + productService.countByCategory(allProducts, cat));
                }
                case 6 -> productService.findMostExpensive(allProducts)
                        .ifPresentOrElse(p -> System.out.println("Самый дорогой: " + p),
                                () -> System.out.println("Список пуст"));
                case 7 -> productService.findCheapest(allProducts)
                        .ifPresentOrElse(p -> System.out.println("Самый дешевый: " + p),
                                () -> System.out.println("Список пуст"));
                case 8 -> System.out.println(client);
                case 9 -> {
                    System.out.print("ID товара: ");
                    int id = sc.nextInt();
                    PayHist receipt = checkoutService.processOrder(client, id); //логикавызова покупок
                    System.out.println("--- Чек операции ---");
                    System.out.println(receipt.getReceipt());
                    System.out.println(receipt.isSuccess() ? "Оплата прошла успешно!" : "Оплата ОТКЛОНЕНА: " + receipt.getStatusMsg());
                }
                case 10 -> {
                    System.out.println("Дебет: " + client.getDebitBalance());
                    System.out.println("Кредит: " + (5000 - client.getCreditAvailable()) + " / Лимит: 5000");
                    System.out.println("Статус: " + client.getFinancialStatus());
                }
                case 11 -> System.out.println(productService.getHistoryReport(client));
                case 12 -> {
                    System.out.print("Сумма: ");
                    client.setDebit(client.getDebit() + sc.nextDouble());
                    System.out.println("Счёт пополнен. Баланс: " + client.getDebit());
                }
                case 13 -> {
                    System.out.println("1 - Дебет, 2 - Кредит");
                    int sw = sc.nextInt();
                    strategy = (sw == 1) ? new DebitPaymentStrategy() : new CreditPaymentStrategy();
                    checkoutService = new CheckoutService(catalog, strategy);
                    System.out.println("Способ оплаты изменён.");
                }
                default -> System.out.println("Неверный ввод");
            }
        }
    }
}
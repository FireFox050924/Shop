import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Catalog catalog = Catalog.getInstance();
        Product p1 = new Computers("ПК Игровой", 111.11);
        Product p2 = new Computers("Монитор", 222.22);
        Product p3 = new Computers("Ноутбук", 333.33);
        Product p4 = new Phone("iPhone", 444.44);
        Product p5 = new Phone("Samsung", 555.55);
        Product p6 = new Phone("Honor", 666.66);
        Product p7 = new Appliance("Тостер", 777.77);
        Product p8 = new Appliance("Холодильник", 888.88);
        Product p9 = new Appliance("Микроволновка", 999.99);

        Category cComputers = new Category("Компьютеры");
        cComputers.addProduct(p1); cComputers.addProduct(p2); cComputers.addProduct(p3);
        catalog.addCategory(cComputers);

        Category cPhones = new Category("Телефоны");
        cPhones.addProduct(p4); cPhones.addProduct(p5); cPhones.addProduct(p6);
        catalog.addCategory(cPhones);

        Category cHome = new Category("Бытовая техника");
        cHome.addProduct(p7); cHome.addProduct(p8); cHome.addProduct(p9);
        catalog.addCategory(cHome);

        Client client = new Client(1, "Максим", 500.0, 5000.0);
        ProductService productService = new ProductService();
        Scanner sc = new Scanner(System.in);
        PaymentStrategy strategy = new DebitPaymentStrategy();
        CheckoutService checkoutService = new CheckoutService(catalog, strategy);

        while (true) {
            System.out.println("\n1. Показать все товары");
            System.out.println("2. Товары дороже X руб.");
            System.out.println("3. Товары дешевле X руб.");
            System.out.println("4. Товары по категории");
            System.out.println("5. Кол-во товаров в категории");
            System.out.println("6. Самый дорогой товар");
            System.out.println("7. Самый дешевый товар");
            System.out.println("8. Информация о клиенте");
            System.out.println("9. Купить товар (по ID)");
            System.out.println("10. Баланс и статус клиента");
            System.out.println("11. История покупок");
            System.out.println("12. Пополнить счет");
            System.out.println("13. Сменить способ оплаты (Дебет/Кредит)");
            System.out.print("Выбор: ");

            try {
                //InvalidMenuChoiceException
                String input = sc.nextLine();
                int choice;
                try {
                    choice = Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    throw new InvalidMenuChoiceException("Введено не число: " + input);
                }

                if (choice < 1 || choice > 13) {
                    throw new InvalidMenuChoiceException("Неверный пункт меню: " + choice);
                }

                var allProducts = catalog.getAllProducts();

                switch (choice) {
                    case 1 -> allProducts.forEach(System.out::println);
                    case 2 -> {
                        System.out.print("Мин. цена: ");
                        double min = readPositiveDouble(sc);
                        productService.findExpensive(allProducts, min).forEach(System.out::println);
                    }
                    case 3 -> {
                        System.out.print("Макс. цена: ");
                        double max = readPositiveDouble(sc);
                        productService.findCheap(allProducts, max).forEach(System.out::println);
                    }
                    case 4 -> {
                        System.out.print("Категория: ");
                        String catName = sc.nextLine();
                        //CategoryNotFoundException
                        try {
                            catalog.findCategoryByName(catName);
                            productService.findByCategory(allProducts, catName).forEach(System.out::println);
                        } catch (CategoryNotFoundException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    case 5 -> {
                        System.out.print("Категория: ");
                        String catName = sc.nextLine();
                        try {
                            catalog.findCategoryByName(catName);
                            System.out.println("Количество: " + productService.countByCategory(allProducts, catName));
                        } catch (CategoryNotFoundException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    case 6 -> productService.findMostExpensive(allProducts)
                            .ifPresentOrElse(p -> System.out.println("Самый дорогой: " + p),
                                    () -> System.out.println("Список пуст"));
                    case 7 -> productService.findCheapest(allProducts)
                            .ifPresentOrElse(p -> System.out.println("Самый дешевый: " + p),
                                    () -> System.out.println("Список пуст"));
                    case 8 -> System.out.println(client);
                    case 9 -> {
                        System.out.print("ID товара: ");
                        int id = readPositiveInt(sc);
                        try {
                            PayHist receipt = checkoutService.processOrder(client, id);
                            System.out.println("--- Чек операции ---");
                            System.out.println(receipt.getReceipt());
                            System.out.println(receipt.isSuccess() ? "Оплата прошла успешно!" : "Оплата ОТКЛОНЕНА: " + receipt.getStatusMsg());
                        } catch (ProductNotFoundException | InvalidCreditUseException e) {
                            System.out.println("Ошибка покупки: " + e.getMessage());
                        }
                    }
                    case 10 -> {
                        System.out.println("Дебет: " + client.getDebitBalance());
                        System.out.println("Кредит: " + (5000 - client.getCreditAvailable()) + " / Лимит: 5000");
                        System.out.println("Статус: " + client.getFinancialStatus());
                    }
                    case 11 -> System.out.println(productService.getHistoryReport(client));
                    case 12 -> {
                        System.out.println("1 - Пополнить дебет");
                        System.out.println("2 - Погасить кредитный долг");
                        System.out.print("Выберите действие: ");
                        int action = readPositiveInt(sc);
                        System.out.print("Сумма: ");
                        double amount = readPositiveDouble(sc);

                        if (action == 1) {
                            client.setDebit(client.getDebit() + amount);
                            System.out.printf("Дебет пополнен на %.2f. Текущий баланс: %.2f%n", amount, client.getDebit());
                        } else if (action == 2) {
                            double currentDebt = client.getCreditDebt();
                            if (currentDebt <= 0) {
                                System.out.println("У вас нет кредитного долга.");
                            } else {
                                if (amount >= currentDebt) {
                                    double change = amount - currentDebt;
                                    client.setCreditDebt(0);
                                    client.setDebit(client.getDebit() + change);
                                    System.out.printf("Кредитный долг полностью погашен!%n");
                                    if (change > 0) {
                                        System.out.printf("Остаток %.2f зачислен на дебетовый счет.%n", change);
                                    }
                                } else {
                                    client.setCreditDebt(currentDebt - amount);
                                    System.out.printf("Долг уменьшен на %.2f. Остаток долга: %.2f%n", amount, client.getCreditDebt());
                                }
                            }
                        } else {
                            throw new InvalidMenuChoiceException("Неверный выбор действия в меню пополнения");
                        }
                    }
                    case 13 -> {
                        System.out.println("1 - Дебет, 2 - Кредит");
                        int sw = readPositiveInt(sc);
                        if (sw == 1) {
                            strategy = new DebitPaymentStrategy();
                        } else if (sw == 2) {
                            strategy = new CreditPaymentStrategy();
                        } else {
                            throw new InvalidMenuChoiceException("Неверный выбор способа оплаты");
                        }
                        checkoutService = new CheckoutService(catalog, strategy);
                        System.out.println("Способ оплаты изменён.");
                    }
                }

            } catch (InvalidMenuChoiceException e) {
                System.out.println("Ошибка меню: " + e.getMessage());
            } catch (InvalidDataException e) {
                //InvalidDataException
                System.out.println("Ошибка данных: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Произошла ошибка: " + e.getMessage());
            }
        }
    }

    //помогатор для валидациии
    private static int readPositiveInt(Scanner sc) {
        String input = sc.nextLine();
        try {
            int val = Integer.parseInt(input);
            if (val <= 0) {
                throw new InvalidDataException("Значение должно быть положительным: " + val);
            }
            return val;
        } catch (NumberFormatException e) {
            throw new InvalidDataException("Введено некорректное целое число: " + input);
        }
    }

    private static double readPositiveDouble(Scanner sc) {
        String input = sc.nextLine();
        try {
            double val = Double.parseDouble(input);
            if (val < 0) {
                throw new InvalidDataException("Значение не может быть отрицательным: " + val);
            }
            return val;
        } catch (NumberFormatException e) {
            throw new InvalidDataException("Введено некорректное число: " + input);
        }
    }
}
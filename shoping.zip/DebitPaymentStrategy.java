public class DebitPaymentStrategy implements PaymentStrategy {
    @Override
    public PayHist pay(Client client, Product product) {
        PayHist receipt;//чек

        if (client.getDebitBalance() >= product.getPrice()) {
            client.setDebit(client.getDebitBalance() - product.getPrice());
            receipt = OrderFactory.create(product.getName(), product.getPrice(), PaymentStatus.SUCCESS, "Списано с дебетового счёта");
        } else {
            receipt = OrderFactory.create(product.getName(), product.getPrice(), PaymentStatus.FAIL, "Недостаточно средств на дебете");
        }

        //история
        client.addHistory(receipt);

        return receipt;
    }
}
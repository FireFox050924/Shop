public class DebitPaymentStrategy implements PaymentStrategy {
    @Override
    public PayHist pay(Client client, Product product) {
        if (client.getDebitBalance() >= product.getPrice()) {
            client.setDebit(client.getDebitBalance() - product.getPrice());
            return OrderFactory.create(product.getName(), product.getPrice(), true, "Списано с дебетового счёта");
        }
        return OrderFactory.create(product.getName(), product.getPrice(), false, "Недостаточно средств на дебете");
    }
}
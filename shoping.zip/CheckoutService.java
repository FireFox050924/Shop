import java.util.Optional;

//буква д из солида
//если убрать сервис то прога не рухнет
//вынес отдельной алгаритм оплаты

public class CheckoutService {
    private final ProductRepository repository;
    private final PaymentStrategy paymentStrategy;

    public CheckoutService(ProductRepository repository, PaymentStrategy paymentStrategy) {
        this.repository = repository;
        this.paymentStrategy = paymentStrategy;
    }

    public PayHist processOrder(Client client, int productId) {
        Optional<Product> productOpt = repository.findById(productId);

        //искл если тавар не найден
        if (productOpt.isEmpty()) {
            throw new ProductNotFoundException("Товар с ID " + productId + " не найден");
        }

        Product product = productOpt.get();

        //проверка на наличее средств
        return paymentStrategy.pay(client, product);
    }
}
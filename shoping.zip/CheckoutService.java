import java.util.Optional;

//буква д из солида
//если убрать сервис то прога не рухнет
//вынес отдельной алгаритм оплаты
public class CheckoutService {
    private final ProductRepository repository;
    private final PaymentStrategy paymentStrategy;

    public CheckoutService(ProductRepository repository, PaymentStrategy paymentStrategy) {
        this.repository = repository;
        this.paymentStrategy = paymentStrategy;
    }

    public PayHist processOrder(Client client, int productId) {//обработка отсутсвия товара
        Optional<Product> productOpt = repository.findById(productId);
        if (productOpt.isEmpty()) {
            return OrderFactory.create("Неизвестный товар", 0, false, "Товар не найден");
        }

        Product product = productOpt.get();
        if (!client.hasEnoughMoney(product.getPrice())) {
            return OrderFactory.create(product.getName(), product.getPrice(), false, "Недостаточно средств");
        }

        //алг оплаты стратегии
        return paymentStrategy.pay(client, product);
    }
}
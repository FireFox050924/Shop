public abstract class Product {
    private static int nId = 1;
    private int id;
    private String name;
    private double price;

    public Product(String name, double price) {
        this.id = nId++;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public abstract void showInfo();
}
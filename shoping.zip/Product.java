public abstract class Product implements Comparable<Product> {
    private static int nId = 1;
    private final int id;
    private final String name;
    private final double price;

    public Product(String name, double price) {
        this.id = nId++;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }

    public abstract String getCategoryName();
    public abstract void showInfo();

    @Override
    public int compareTo(Product o) {
        return Double.compare(this.price, o.price);
    }

    @Override
    public String toString() {
        return name + " - " + price + " руб. [" + getCategoryName() + "]";
    }
}
import java.util.ArrayList;
import java.util.Comparator;

//отвечает только за данные товара
public abstract class Product implements Comparable<Product> {
    private static int nId = 1;
    private int id;
    private String name;
    private double price;

    public Product(String name, double price) {
        this.id = nId++;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }

    //фильтрации по категории
    public abstract String getCategoryName();

    public abstract void showInfo();

    @Override
    public int compareTo(Product other) {
        return Double.compare(other.price, this.price);
    }

    @Override
    public String toString() {
        return name + " - " + price + " руб. [" + getCategoryName() + "]";
    }

    public static void sortPriceLambda(ArrayList<Product> products) {
        products.sort((p1, p2) -> Double.compare(p2.getPrice(), p1.getPrice()));
    }
}
public class Computers extends Product {
    public Computers(String name, double price) {
        super(name, price);
    }

    @Override
    public void showInfo() {
        System.out.println("ПК: " + getName() + " " + getPrice());
    }

    @Override
    public String getCategoryName() {
        return "Компьютеры";
    }
}
public class Computers extends Product {
    public Computers(String name, double price) {
        super(name, price);
    }

    @Override
    public void showInfo() {
        System.out.println(getName() + " " + getPrice());
    }
}
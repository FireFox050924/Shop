public interface PaymentStrategy {
    PayHist pay(Client client, Product product);
}//меняется поведение без изменения CheckoutService